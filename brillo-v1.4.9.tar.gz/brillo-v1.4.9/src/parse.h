/* SPDX-License-Identifier: GPL-3.0-only */

#ifndef PARSE_H
#define PARSE_H

#include "light.h"

bool parse_args(int argc, char **argv, struct light_conf *ctx);

#endif /* PARSE_H */
